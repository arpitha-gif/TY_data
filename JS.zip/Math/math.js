console.log(Math.round(1.8));
console.log(Math.abs(-6));
console.log(Math.pow(2,8));
console.log(Math.min(5,6));
console.log(Math.max(5,6,90));
console.log(Math.ceil(12.5));
console.log(Math.floor(12.2));
console.log(Math.random());

// generate random Node. between 1 to 100 

console.log(Math.ceil(Math.random()*100)+1)
