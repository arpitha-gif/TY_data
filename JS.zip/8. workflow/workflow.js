// demo 1 
function first (){
    setTimeout(function(){
        console.log("first function ")
    },0)
    console.log('test ur brain');
}

function second (){
    console.log("second function ")
}
first()
second()

console.log('==========================');

// demo2 
function first (){
    setTimeout(function(){
        console.log("first function ")
    },0)

    console.log('test ur brain');
}

function second (){
    console.log("second function ")
}
function third (){
    console.log("third function ")
}
first()
second()
third()

// console.log('=====================');

// demo3 
function first (){
    setTimeout(function(){
        console.log("first function ")
    },0)

    console.log('test ur brain');
}

function second (){
    console.log("second function ")
}

function third (){
    setTimeout(function(){
        console.log("third function ")
    },0)
}
first()
second()
third()